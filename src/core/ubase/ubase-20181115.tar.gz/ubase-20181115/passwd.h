/* See LICENSE file for copyright and license details. */
/* passwd.c */
int pw_check(const struct passwd *, const char *);
int pw_init(void);
