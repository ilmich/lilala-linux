/* See LICENSE file for copyright and license details. */

#define ENV_SUPATH	"/bin"
#define ENV_PATH	"/bin"
#define PW_CIPHER	"$6$"	/* SHA-512 */
#undef UTMP_PATH
#define UTMP_PATH	"/var/run/utmp"
#undef BTMP_PATH
#define BTMP_PATH	"/var/log/btmp"
#undef WTMP_PATH
#define WTMP_PATH	"/var/log/wtmp"
