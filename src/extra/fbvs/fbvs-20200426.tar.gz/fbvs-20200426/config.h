#define IDSTRING "fbvs 1.0, s-tech"
#define DEFAULT_FRAMEBUFFER "/dev/fb0"
